let _main = document.getElementsByTagName('main')[0]
let _name = document.getElementsByClassName('name')[0]
let _body = document.getElementsByTagName('body')[0]
let _explain = document.getElementsByClassName('explain')[0]
let _big = document.getElementById('big')
let _gif1 = document.getElementById('gif1')
let _gif2 = document.getElementById('gif2')
let _gif3 = document.getElementById('gif3')
let _gif4 = document.getElementById('gif4')
let _hand = document.getElementById('hand')
let _gif5 = document.getElementById('gif5')
let _gif6 = document.getElementById('gif6')
let _gif7 = document.getElementById('gif7')
let _gif8 = document.getElementById('gif8')
let _gif9 = document.getElementById('gif9')
let _gif10 = document.getElementById('gif10')
let _gif11 = document.getElementById('gif11')
let _gif12 = document.getElementById('gif12')
let _gif13 = document.getElementById('gif13')
let _gif14 = document.getElementById('gif14')
let _gif15 = document.getElementById('gif15')
let _gif16 = document.getElementById('gif16')
let _gif17 = document.getElementById('gif17')
let _gif18 = document.getElementById('gif18')
let _gif19 = document.getElementById('gif19')
let _gif20 = document.getElementById('gif20')
let _gif21 = document.getElementById('gif21')
let _gif1Right = parseInt(window.getComputedStyle(_gif1).getPropertyValue('right'))
let _gif2Right = parseInt(window.getComputedStyle(_gif2).getPropertyValue('right'))
let _gif3Right = parseInt(window.getComputedStyle(_gif3).getPropertyValue('right'))
let _gif4Right = parseInt(window.getComputedStyle(_gif4).getPropertyValue('right'))
let _handRight = parseInt(window.getComputedStyle(_hand).getPropertyValue('right'))
let _gif5Right = parseInt(window.getComputedStyle(_gif5).getPropertyValue('right'))
let _gif6Right = parseInt(window.getComputedStyle(_gif6).getPropertyValue('right'))
let _gif7Right = parseInt(window.getComputedStyle(_gif7).getPropertyValue('right'))
let _gif8Right = parseInt(window.getComputedStyle(_gif8).getPropertyValue('right'))
let _gif9Right = parseInt(window.getComputedStyle(_gif9).getPropertyValue('right'))
let _gif10Right = parseInt(window.getComputedStyle(_gif10).getPropertyValue('right'))
let _gif11Right = parseInt(window.getComputedStyle(_gif11).getPropertyValue('right'))
let _gif12Right = parseInt(window.getComputedStyle(_gif12).getPropertyValue('right'))
let _gif13Right = parseInt(window.getComputedStyle(_gif13).getPropertyValue('right'))
let _gif14Right = parseInt(window.getComputedStyle(_gif14).getPropertyValue('right'))
let _gif15Right = parseInt(window.getComputedStyle(_gif15).getPropertyValue('right'))
let _gif16Right = parseInt(window.getComputedStyle(_gif16).getPropertyValue('right'))
let _gif17Right = parseInt(window.getComputedStyle(_gif17).getPropertyValue('right'))
let _gif18Right = parseInt(window.getComputedStyle(_gif18).getPropertyValue('right'))
let _gif19Right = parseInt(window.getComputedStyle(_gif19).getPropertyValue('right'))
let _gif20Right = parseInt(window.getComputedStyle(_gif20).getPropertyValue('right'))
let _gif21Right = parseInt(window.getComputedStyle(_gif21).getPropertyValue('right'))


_main.addEventListener('scroll', () => {
    let st = _main.scrollTop

    _explain.style.top = -st / 20 + '%'
    _gif1.style.right = ((_gif1Right) + (st) / 1.5) + 'px'
    _gif2.style.right = ((_gif2Right) + (st) / 1.3) + 'px'
    _gif3.style.right = ((_gif3Right) + (st) / 1.5) + 'px'
    _gif4.style.right = ((_gif4Right) + (st) / 1.4) + 'px'
    _hand.style.right = ((_handRight) + (st) / 1.4) + 'px'
    _gif5.style.right = ((_gif5Right) + (st) / 1.5) + 'px'
    _gif6.style.right = ((_gif6Right) + (st) / 1.5) + 'px'
    _gif7.style.right = ((_gif7Right) + (st) / 1.5) + 'px'
    _gif8.style.right = ((_gif8Right) + (st) / 1.5) + 'px'
    _gif9.style.right = ((_gif9Right) + (st) / 1.5) + 'px'
    _gif10.style.right = ((_gif10Right) + (st) / 1.5) + 'px'
    _gif11.style.right = ((_gif11Right) + (st) / 1.5) + 'px'
    _gif12.style.right = ((_gif12Right) + (st) / 1.5) + 'px'
    _gif13.style.right = ((_gif13Right) + (st) / 1.5) + 'px'
    _gif14.style.right = ((_gif14Right) + (st) / 1.5) + 'px'
    _gif15.style.right = ((_gif15Right) + (st) / 1.5) + 'px'
    _gif16.style.right = ((_gif16Right) + (st) / 1.5) + 'px'
    _gif17.style.right = ((_gif17Right) + (st) / 1.5) + 'px'
    _gif18.style.right = ((_gif18Right) + (st) / 1.5) + 'px'
    _gif19.style.right = ((_gif19Right) + (st) / 1.5) + 'px'
    _gif20.style.right = ((_gif20Right) + (st) / 1.5) + 'px'
    _gif21.style.right = ((_gif21Right) + (st) / 1.5) + 'px'
    console.log((_gif2Right) + (st))
    if (parseInt(_gif1.style.right, 10) > -100) {
        _name.classList.add('add')
    } else if (parseInt(_gif1.style.right, 10) < -300) {
        _name.classList.remove('add')
    }
    console.log(parseInt(_gif1.style.right, 10))

})

_main.addEventListener('mousemove', (event) => {
    let x = event.clientX
    let y = event.clientY
    _big.style.left = x + 'px'
    _big.style.top = y + 'px'
    // console.log(x)
})
_main.addEventListener('mousedown', () => {
    _big.style.border = '20px solid white'
    _big.style.transition = '.2s'
})
_main.addEventListener('mouseup', () => {
    _big.style.border = '3px solid white'
    _big.style.transition = '0s'
})